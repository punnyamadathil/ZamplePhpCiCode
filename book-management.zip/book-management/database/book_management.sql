-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2024 at 08:27 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `book_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `bm_books`
--

CREATE TABLE `bm_books` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `description` varchar(2500) NOT NULL,
  `publish_date` date NOT NULL,
  `pdf_file` varchar(250) NOT NULL,
  `category_id` int(11) DEFAULT 0,
  `category_name` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL,
  `active` int(2) NOT NULL DEFAULT 1,
  `status` int(2) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bm_books`
--

INSERT INTO `bm_books` (`id`, `user_id`, `title`, `author`, `description`, `publish_date`, `pdf_file`, `category_id`, `category_name`, `created_at`, `updated_at`, `active`, `status`) VALUES
(1, 1, 'abc', 'abc', 'abc\r\n												', '2024-04-11', 'uploads/anjali-adjst-add-101.pdf', 0, NULL, '2024-04-18 07:21:49', '2024-04-18 07:11:46', 0, 0),
(2, 1, 'qwerty abc', 'qwerty', 'qwerty', '2024-04-04', 'uploads/Task_Create_a_Basic_CRUD_Application_with_User_Authenticatio_2_(1)_(1)4.pdf', 0, NULL, '2024-04-18 07:24:09', '2024-04-18 07:09:32', 0, 0),
(3, 1, 'test edit', 'vho', 'vghv', '2024-04-17', 'uploads/anjali-adjst-add-102.pdf', 3, 'njo', '2024-04-18 11:40:20', '2024-04-18 08:12:32', 0, 0),
(4, 1, 'npk;', 'jejfipgde', 'fjrsgjvsd', '2024-04-01', 'uploads/anjali-adjst-add-103.pdf', 2, 'jnpi', '2024-04-18 11:46:58', '0000-00-00 00:00:00', 1, 1),
(5, 1, 'test', 'ndjew', 'fbwrjbf', '2024-04-20', 'uploads/anjali-adjst-add-104.pdf', 1, 'asd', '2024-04-18 11:52:05', '0000-00-00 00:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bm_category`
--

CREATE TABLE `bm_category` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL,
  `active` int(2) NOT NULL DEFAULT 1,
  `status` int(2) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bm_category`
--

INSERT INTO `bm_category` (`id`, `user_id`, `category`, `created_at`, `updated_at`, `active`, `status`) VALUES
(1, 1, 'asd', '2024-04-18 07:41:00', '0000-00-00 00:00:00', 1, 1),
(2, 1, 'oooo', '2024-04-18 07:49:56', '2024-04-18 08:27:34', 0, 0),
(3, 1, 'njo', '2024-04-18 07:50:08', '0000-00-00 00:00:00', 1, 1),
(4, 1, 'ijpi', '2024-04-18 07:52:53', '0000-00-00 00:00:00', 1, 1),
(5, 1, 'test1', '2024-04-18 11:42:57', '2024-04-18 08:13:25', 0, 0),
(6, 1, 'ghi', '2024-04-18 11:43:34', '0000-00-00 00:00:00', 1, 1),
(7, 1, 'dsfsd', '2024-04-18 11:52:56', '0000-00-00 00:00:00', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bm_users`
--

CREATE TABLE `bm_users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `email` int(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL,
  `active` int(2) NOT NULL DEFAULT 1,
  `status` int(2) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bm_users`
--

INSERT INTO `bm_users` (`id`, `full_name`, `email`, `password`, `created_at`, `updated_at`, `active`, `status`) VALUES
(1, 'punnya madhu', 0, 'XT1UbgRjBTEPPgMyBTEFNQ==', '2024-04-18 07:08:42', '0000-00-00 00:00:00', 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bm_books`
--
ALTER TABLE `bm_books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `title` (`title`),
  ADD KEY `author` (`author`);

--
-- Indexes for table `bm_category`
--
ALTER TABLE `bm_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bm_users`
--
ALTER TABLE `bm_users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bm_books`
--
ALTER TABLE `bm_books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `bm_category`
--
ALTER TABLE `bm_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `bm_users`
--
ALTER TABLE `bm_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
