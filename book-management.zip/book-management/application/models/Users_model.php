<?php
class Users_model extends CI_Model {
    public function add($data,$table) {
        //echo $table;exit;
        return $this->db->insert($table, $data);
    }
    public function user_login($username,$password){ 
        $query = $this->db->query("select id,password,full_name,email from bm_users where `email`='$username' and status=1");
       
       
        if($query->num_rows() == 1){
            
           $user=$query->row_array();
            
           $this->load->library('encrypt');
           $pass =  $this->encrypt->decode($user['password']);
           if($pass == $password){
            
                return $user; 
            }
           else{
            
                return FALSE;
            }
        }
        else{
            return FALSE;
        }
        
        
    }
    public function getAllByUser($where,$table){

        $this->db->where($where);
        $this->db->where('active',1);
        $this->db->where('status',1);
        $this->db->order_by('id', 'desc');
        $query=$this->db->get($table);
        return $query->result_array();
        
    }
    public function getAllById($where,$table){

        $this->db->where($where);
        $this->db->where('active',1);
        $this->db->where('status',1);
        $this->db->order_by('id', 'desc');
        $query=$this->db->get($table);
        return $query->row_array();
        
    }
    public function update_data($where,$data,$table){
		$this->db->update($table,$data,$where);
		return ($this->db->affected_rows() > 0) ? TRUE : FALSE;
  }
}