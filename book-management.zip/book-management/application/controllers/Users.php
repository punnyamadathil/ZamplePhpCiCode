<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __construct() {
        parent::__construct();
        $this->load->model('users_model');
        $this->load->library('form_validation');
        $this->load->helper(array('form', 'url'));

    }
	public function index()
	{
		$this->load->view('sign-in');
	}
	public function sign_up()
	{
		$this->load->view('sign-up');
	}
	public function register()
	{
		$this->form_validation->set_rules(
            'full_name', 'Full Name',
            'required|min_length[3]|max_length[15]',
            array(
                'required' => 'You have not provided %s.'
            )
        );

        $this->form_validation->set_rules(
            'password', 'Password', 
            'required',
            array(
                'required' => 'You have not provided %s.'
            )
        );

        /* $this->form_validation->set_rules(
            'cpwd', 'Password Confirmation', 
            'required|matches[pwd]',
            array(
                'required' => 'You have not provided %s.',
                'matches' => 'The password confirmation does not match.'
            )
        ); */

        $this->form_validation->set_rules(
            'email', 'Email', 
            'trim|required|valid_email',
            array(
                'required' => 'You have not provided %s.',
                'valid_email' => 'Please provide a valid %s.'
            )
        );

        if ($this->form_validation->run() == FALSE) {
            $this->load->view('sign-up');
        } 
		else {
            $this->load->library('encrypt');
			$password = $this->input->post('password');
            $password = $this->encrypt->encode($password);
            $data = array(
                'full_name' => $this->input->post('full_name'),
                'email' => $this->input->post('email'),
                'password' => $password
            );

            $register = $this->users_model->add($data,'bm_users');

            if($register) {
                $this->session->set_flashdata('success', 'Registration successful');
                redirect('sign-in');
            } 
        }
	}
	public function login()
	{
		$this->form_validation->set_rules(
            'email', 'Email', 
            'trim|required|valid_email',
            array(
                'required' => 'You have not provided %s.',
                'valid_email' => 'Please provide a valid %s.'
            )
        );
        $this->form_validation->set_rules(
            'password', 'Password', 
            'required',
            array(
                'required' => 'You have not provided %s.'
            )
        );
        if ($this->form_validation->run() == FALSE) {
            $this->load->view('sign-in');
        } else {
			
            $password = $this->input->post('password');
            $username = $this->input->post('email');
               
                $user=$this->users_model->user_login($username,$password);
                if($user)
                {
					$user_data = array(
						'user_id'  => $user['id'],
						'name'     => $user['full_name'],
						'email'     => $user['email'],
						'logged_in' => TRUE
					);
                    $this->session->set_userdata($user_data);

                    redirect('dashboard');
                }
                else{

                    $this->load->view('sign-in');
                }

       


    }
	}
	public function dashboard()
	{
		if($this->session->userdata('user_id') || $this->session->userdata('logged_in')==TRUE){
			$this->load->view('dashboard');
		}else{
			redirect('sign-in');
		}
	}
	public function add_book()
	{  if($this->session->userdata('user_id') || $this->session->userdata('logged_in')==TRUE){
		$data['title']='Add-Book';
		$data['card_title']='Add Book';
		$where['user_id']=$this->session->userdata('user_id'); 
		$data['categories']=$this->users_model->getAllByUser(array(),'bm_category');
		
			$this->load->view('add-book',$data);
		}else{
			redirect('sign-in');
		}
	}
	public function insert_book()
	{
		$user_input_array=$default_array=array();
		$this->form_validation->set_rules(
            'title', 'Title',
            'required|min_length[3]|max_length[15]',
            array(
                'required' => 'You have not provided %s.'
            )
        );
		$this->form_validation->set_rules(
            'author', 'Author',
            'required|min_length[3]|max_length[15]',
            array(
                'required' => 'You have not provided %s.'
            )
        );
		$this->form_validation->set_rules(
            'description', 'Description',
            'trim|required|min_length[3]|max_length[2000]',
            array(
                'required' => 'You have not provided %s.'
            )
        );
		$this->form_validation->set_rules(
            'publish_date', 'Publication Date',
            'required',
            array(
                'required' => 'You have not provided %s.'
            )
        );
		// $this->form_validation->set_rules(
        //     'pdf_file', 'PdfPublication	Date',
        //     'required',
        //     array(
        //         'required' => 'You have not provided %s.'
        //     )
        // );
		if ($this->form_validation->run() == FALSE) {
			$data['title']='Add-Book';
			$data['card_title']='Add Book';
            $this->load->view('add-book',$data);
        } else {
			$params = ['title', 'author',  'description','publish_date','category_id','category_name'];
			foreach ( $params as $param ) {
				$user_input_array[ $param ] = $this->input->post( $param );
			}
			if (!empty($_FILES['pdf_file']['name'])) {
				$config['upload_path']          = './uploads/';
				$config['allowed_types']        = 'pdf';
				$config['min_size']             = 1024;

				$this->load->library('upload', $config);

				if ( ! $this->upload->do_upload('pdf_file'))
				{
						$error = array('error' => $this->upload->display_errors());
						
						$this->load->view('add-book', $error);
				}
				else
				{
					$data = $this->upload->data();
					$user_input_array['pdf_file'] = 'uploads/' . $data['file_name'];
					
				}
			}
			$default_array['user_id']=$this->session->userdata('user_id'); 
			
			//var_dump($input_array);exit;
			$update_id= $this->input->post( 'update_id' );
			if($update_id==0){
				$input_array = array_merge($user_input_array,$default_array);
				$book = $this->users_model->add($input_array,'bm_books');

				if($book) {
					$this->session->set_flashdata('success', 'New Book added successfully');
					redirect('add-book');
				} 
			}else{
				
				$manipulated_array['updated_at']=date('Y-m-d H:i:s');
				$input_array = array_merge($user_input_array,$default_array,$manipulated_array);
				$where['id']=$update_id;
				$book = $this->users_model->update_data($where,$input_array,'bm_books');

				if($book) {
					$this->session->set_flashdata('success', 'The Book Updated successfully');
					redirect('add-book');
				} 
			}
		}
	}
	public function all_books()
	{  if($this->session->userdata('user_id') || $this->session->userdata('logged_in')==TRUE){
		//$where['user_id']=$this->session->userdata('user_id'); 
		$data['books']=$this->users_model->getAllByUser(array(),'bm_books');
		
			$this->load->view('all-books',$data);
		}else{
			redirect('sign-in');
		}
	}
	public function my_books()
	{  if($this->session->userdata('user_id') || $this->session->userdata('logged_in')==TRUE){
		$where['user_id']=$this->session->userdata('user_id'); 
		$data['books']=$this->users_model->getAllByUser($where,'bm_books');
		$this->load->view('my-books',$data);
		}else{
			redirect('sign-in');
		}
	}
		public function edit_book($id)
	{
		$where['id']=$id; 
		$data['title']='Edit-Book';
		$data['card_title']='Edit Book';
		$data['book']=$this->users_model->getAllById($where,'bm_books');
		$data['categories']=$this->users_model->getAllByUser(array(),'bm_category');
		$this->load->view('add-book',$data);
	}
	public function delete_book($id){
			$manipulated_array['updated_at']=date('Y-m-d H:i:s');
			$manipulated_array['active']=0;
			$manipulated_array['status']=0;
				
				$where['id']=$id;
				$book = $this->users_model->update_data($where,$manipulated_array,'bm_books');
				if($book){
					$response['message'] = 'Success!! ,Removed  succesfully';
            
				}else{
					$response['message'] = 'Failed!! ,Something Went wrong';
				}
				echo json_encode($response);

	}
	public function add_category()
	{  if($this->session->userdata('user_id') || $this->session->userdata('logged_in')==TRUE){
		$data['title']='Add-Category';
		$data['card_title']='Add Category';
			$this->load->view('add-category',$data);
		}else{
			redirect('sign-in');
		}
	}
	public function insert_category()
	{
		$user_input_array=$default_array=array();
		$this->form_validation->set_rules(
            'category', 'Category Name',
            'required|min_length[3]|max_length[15]',
            array(
                'required' => 'You have not provided %s.'
            )
        );
		
		
		if ($this->form_validation->run() == FALSE) {
			$data['title']='Add-Category';
			$data['card_title']='Add Category';
            $this->load->view('add-category',$data);
        } else {
			$params = ['category'];
			foreach ( $params as $param ) {
				$user_input_array[ $param ] = $this->input->post( $param );
			}
			
			$default_array['user_id']=$this->session->userdata('user_id');
			$update_id= $this->input->post('update_id');
			if($update_id==0) {
				$input_array = array_merge($user_input_array,$default_array);
				//var_dump($input_array);exit;
				$category = $this->users_model->add($input_array,'bm_category');
				if($category) {
					$this->session->set_flashdata('success', 'New Category added successfully');
					redirect('add-category');
				} 
			}else{
				$manipulated_array['updated_at']=date('Y-m-d H:i:s');
				$input_array = array_merge($user_input_array,$default_array,$manipulated_array);
				$where['id']=$update_id;
				$category = $this->users_model->update_data($where,$input_array,'bm_category');

				if($category) {
					$this->session->set_flashdata('success', 'The category updated successfully');
					redirect('add-category');
				} 
			}
		}
	}
	public function view_category()
	{  if($this->session->userdata('user_id') || $this->session->userdata('logged_in')==TRUE){
		$data['category']=$this->users_model->getAllByUser(array(),'bm_category');
			$this->load->view('view-category',$data);
		}else{
			redirect('sign-in');
		}
	}
	public function edit_category($id)
	{
		$where['id']=$id; 
		$data['title']='Edit-Category';
		$data['card_title']='Edit Category';
		$data['cate']=$this->users_model->getAllById($where,'bm_category');
		
		$this->load->view('add-category',$data);
	}
	public function delete_category($id){
			$manipulated_array['updated_at']=date('Y-m-d H:i:s');
			$manipulated_array['active']=0;
			$manipulated_array['status']=0;
				
				$where['id']=$id;
				$book = $this->users_model->update_data($where,$manipulated_array,'bm_category');
				if($book){
					$response['message'] = 'Success!! ,Removed  succesfully';
            
				}else{
					$response['message'] = 'Failed!! ,Something Went wrong';
				}
				echo json_encode($response);

	}
	public function logout() {
		$this->session->sess_destroy();
		redirect('sign-in');
	  }
}
