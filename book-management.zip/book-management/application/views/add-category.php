<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title><?php echo $title; ?></title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
	<link rel="stylesheet" href="<?php echo site_url('public/');?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
	<link rel="stylesheet" href="<?php echo site_url('public/');?>assets/css/ready.css">
	<link rel="stylesheet" href="<?php echo site_url('public/');?>assets/css/demo.css">
</head>
<body>
	<div class="wrapper">
		<?php  $this->load->view('main-header'); ?>
		<?php  $this->load->view('sidebar'); ?>
			<div class="main-panel">
				<div class="content">
					<div class="container-fluid">
						<h4 class="page-title">Forms</h4>
						<div class="row">
							<div class="col-md-12">
								<div class="card">
									<div class="card-header">
										<div class="card-title"><?php echo $card_title; ?></div>
									</div>
									<?php if ($this->session->flashdata('success')) : ?>
										<div class="alert alert-success">
											<?php echo $this->session->flashdata('success'); ?>
										</div>
									<?php endif; ?>
									<form method="POST" class="category-form" id="category-form" action="<?php echo base_url()?>insert_category" >
									<input type="hidden" name="update_id" value="<?php if(isset($cate['id'])){echo $cate['id'];}else{ echo 0;} ?>">
										<div class="card-body">
											<div class="form-group">
												<label for="category">Category Name</label>
												<input type="text" class="form-control" id="category" placeholder="Category Name" name="category" value="<?php if(isset($cate['category'])){echo $cate['category'];} ?>">
												<?php echo form_error('category','<div class="error" style="color:red;">','</div>');?>
											</div>
											
											<div class="card-action">
											<?php if(isset($cate['id'])){?>
												<button class="btn btn-success">Update</button>
												<?php } else { ?>
												<button class="btn btn-success">Add</button>
												<?php } ?>
												<button class="btn btn-danger">Cancel</button>
											</div>
										</div>
									</form>
								</div>
								
							</div>
						</div>
					</div>
					<footer class="footer">
						<div class="container-fluid">
							
							<div class="copyright ml-auto">
								2024, made with <i class="la la-heart heart text-danger"></i> by <a href="#">Abc</a>
							</div>				
						</div>
					</footer>
				</div>
			</div>
		</div>
	</div>
	<!-- Modal -->
	<div class="modal fade" id="modalUpdate" tabindex="-1" role="dialog" aria-labelledby="modalUpdatePro" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header bg-primary">
					<h6 class="modal-title"><i class="la la-frown-o"></i> Under Development</h6>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body text-center">									
					<p>Currently the pro version of the <b>Ready Dashboard</b> Bootstrap is in progress development</p>
					<p>
					<b>We'll let you know when it's done</b></p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
</body>
<script src="<?php echo site_url('public/');?>assets/js/core/jquery.3.2.1.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/core/popper.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/core/bootstrap.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/chartist/chartist.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/chartist/plugin/chartist-plugin-tooltip.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/jquery-mapael/maps/world_countries.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/chart-circle/circles.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/ready.min.js"></script>
</html>