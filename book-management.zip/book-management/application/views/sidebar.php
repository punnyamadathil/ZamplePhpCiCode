<div class="sidebar">
				<div class="scrollbar-inner sidebar-wrapper">
					<div class="user">
						<div class="photo">
							<img src="<?php echo site_url('public/');?>assets/img/profile.jpg">
						</div>
						<div class="info">
							<a class="" data-toggle="collapse" href="#collapseExample" aria-expanded="true">
								<span>
									Hizrian
									<span class="user-level">Administrator</span>
									<span class="caret"></span>
								</span>
							</a>
							<div class="clearfix"></div>

							<div class="collapse in" id="collapseExample" aria-expanded="true" style="">
								<ul class="nav">
									<li>
										<a href="#profile">
											<span class="link-collapse">My Profile</span>
										</a>
									</li>
									<li>
										<a href="#edit">
											<span class="link-collapse">Edit Profile</span>
										</a>
									</li>
									<li>
										<a href="#settings">
											<span class="link-collapse">Settings</span>
										</a>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<ul class="nav">
						<li class="nav-item active">
							<a href="index.html">
								<i class="la la-dashboard"></i>
								<p>Dashboard</p>
								<span class="badge badge-count">5</span>
							</a>
						</li>
						
						<li class="nav-item">
							<a href="<?php echo base_url(); ?>add-book">
								<i class="la la-keyboard-o"></i>
								<p>Add Book</p>
								
							</a>
						</li>
						<li class="nav-item">
							<a href="<?php echo base_url(); ?>my-books">
								<i class="la la-th"></i>
								<p>My Books</p>
								
							</a>
						</li>
                        <li class="nav-item">
							<a href="<?php echo base_url(); ?>all-books">
								<i class="la la-th"></i>
								<p>All Books</p>
								
							</a>
						</li>
                        <li class="nav-item">
							<a href="<?php echo base_url(); ?>add-category">
								<i class="la la-th"></i>
								<p>Add Category</p>
								
							</a>
						</li>
                        <li class="nav-item">
							<a href="<?php echo base_url(); ?>view-category">
								<i class="la la-th"></i>
								<p>View Category</p>
								
							</a>
						</li>
                        <li class="nav-item">
							<a href="<?php echo base_url(); ?>logout">
								<i class="la la-th"></i>
								<p>Logout</p>
								
							</a>
						</li>
						
					</ul>
				</div>
			</div>