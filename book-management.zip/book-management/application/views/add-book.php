<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
	<title><?php echo $title; ?></title>
	<meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
	<link rel="stylesheet" href="<?php echo site_url('public/');?>assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
	<link rel="stylesheet" href="<?php echo site_url('public/');?>assets/css/ready.css">
	<link rel="stylesheet" href="<?php echo site_url('public/');?>assets/css/demo.css">
</head>
<body>
	<div class="wrapper">
		<?php  $this->load->view('main-header'); ?>
		<?php  $this->load->view('sidebar'); ?>
			<div class="main-panel">
				<div class="content">
					<div class="container-fluid">
						<h4 class="page-title">Forms</h4>
						<div class="row">
							<div class="col-md-12">
								<div class="card">
									<div class="card-header">
										<div class="card-title"><?php echo $card_title; ?></div>
									</div>
									<?php if ($this->session->flashdata('success')) : ?>
										<div class="alert alert-success">
											<?php echo $this->session->flashdata('success'); ?>
										</div>
									<?php endif; ?>
									<form method="POST" class="book-form" id="book_form" name="book_form" action="<?php echo base_url()?>insert_book" enctype="multipart/form-data" >
										<input type="hidden" name="update_id" value="<?php if(isset($book['id'])){echo $book['id'];}else{ echo 0;} ?>">
										<div class="card-body">
											<div class="form-group">
												<label for="title">Title</label>
												<input type="text" class="form-control" id="title" placeholder="Title" name="title" value="<?php if(isset($book['title'])){echo $book['title'];}else{ echo '';} ?>">
												<?php echo form_error('title','<div class="error" style="color:red;">','</div>');?>
											</div>
											<div class="form-group">
												<label for="author">Author</label>
												<input type="text" class="form-control" id="author" placeholder="Author" name="author" value="<?php if(isset($book['author'])){echo $book['author'];}else{ echo '';} ?>">
												<?php echo form_error('author','<div class="error" style="color:red;">','</div>');?>
											</div>
											<div class="form-group">
												<label for="description">Description</label>
												<textarea class="form-control" id="description" name="description" >
												<?php if(isset($book['description'])){echo $book['description'];}else{ echo '';} ?>
												</textarea>
												<?php echo form_error('description','<div class="error" style="color:red;">','</div>');?>
											</div>
											<div class="form-group">
												<label for="publish_date">Publish Date</label>
												<input type="date" class="form-control" id="publish_date" placeholder="Publish Date" name="publish_date" value="<?php if(isset($book['publish_date'])){echo $book['publish_date'];}else{ echo '';} ?>">
												<?php echo form_error('publish_date','<div class="error" style="color:red;">','</div>');?>
											</div>
											<div class="form-group">
												<label for="category_id">Example select</label>
												<select class="form-control" id="category_id" name="category_id" required onchange="assignRowValue(this, 'book_form', '#category_name');">
												<option value="0" >-- Select --</option>
												<?php if(isset($categories)){
														foreach($categories as $cate){
												?>
												<option value="<?php echo $cate['id']; ?>" <?php if(isset($book['category_id'])){ if($book['category_id']==$cate['id']){ echo 'selected'; } }?>><?php echo $cate['category']; ?></option>
												<?php }} ?>	
												</select>
												<input type="hidden" name="category_name" id="category_name" value="<?php if(isset($book['category_name'])){echo $book['category_name']; }?>">
											</div>
											
											<div class="form-group">
												
												<div class="form-group">
													<label for="pdf_file">Add Pdf</label>
													<input type="file" class="form-control-file" id="pdf_file" name="pdf_file" accept=".pdf" >
													<?php if(isset($book['pdf_file'])){?>
													<label for="pre_file">Previous Pdf</label> &nbsp; <a href="<?php echo base_url().$book['pdf_file']; ?>" type="button" class="btn btn-primary">view pdf</a>
													<?php } ?>
													<?php echo form_error('pdf_file','<div class="error" style="color:red;">','</div>');?>
												</div>
												
											</div>
											<div class="card-action">
												<?php if(isset($book['id'])){?>
												<button class="btn btn-success">Update</button>
												<?php } else { ?>
												<button class="btn btn-success">Add</button>
												<?php } ?>
												<button class="btn btn-danger">Cancel</button>
											</div>
										</div>
									</form>
								</div>
								
							</div>
						</div>
					</div>
					<footer class="footer">
						<div class="container-fluid">
							
							<div class="copyright ml-auto">
								2024, made with <i class="la la-heart heart text-danger"></i> by <a href="#">Abc</a>
							</div>				
						</div>
					</footer>
				</div>
			</div>
		</div>
	</div>
	<!-- Modal -->
	<div class="modal fade" id="modalUpdate" tabindex="-1" role="dialog" aria-labelledby="modalUpdatePro" aria-hidden="true">
		<div class="modal-dialog modal-dialog-centered" role="document">
			<div class="modal-content">
				<div class="modal-header bg-primary">
					<h6 class="modal-title"><i class="la la-frown-o"></i> Under Development</h6>
					<button type="button" class="close" data-dismiss="modal" aria-label="Close">
						<span aria-hidden="true">&times;</span>
					</button>
				</div>
				<div class="modal-body text-center">									
					<p>Currently the pro version of the <b>Ready Dashboard</b> Bootstrap is in progress development</p>
					<p>
					<b>We'll let you know when it's done</b></p>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>
</body>
<script src="<?php echo site_url('public/');?>assets/js/core/jquery.3.2.1.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/core/popper.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/core/bootstrap.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/chartist/chartist.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/chartist/plugin/chartist-plugin-tooltip.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/bootstrap-toggle/bootstrap-toggle.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/jquery-mapael/jquery.mapael.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/jquery-mapael/maps/world_countries.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/chart-circle/circles.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>
<script src="<?php echo site_url('public/');?>assets/js/ready.min.js"></script>

<script src="<?php echo site_url('public/');?>assets/js/main.js"></script>
</html>