function delete_data(type,id, msg= "", msg_txt= "Data will be deleted") {
   var serverurl="http://localhost/book-management/";
   url= serverurl+'delete-'+type+'/'+id;
   
   // $('#alert_demo_7').click(function(e) {
        swal({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            type: 'warning',
            buttons:{
                confirm: {
                    text : 'Yes, do it!',
                    className : 'btn btn-success'
                },
                cancel: {
                    visible: true,
                    className: 'btn btn-danger'
                }
            }
        }).then((Delete) => {
            if (Delete) {

                $.ajax({
                    url: url,
                    type: 'get',
                    
                    success: function(json) {
                        var obj = jQuery.parseJSON(json);
                       if(obj.message){
                        msg_txt = obj.message;
                       }else{
                        msg_txt = 'Your file has been deleted.';
                       }
                        swal({
                            title: 'Deleted',
                            text: msg_txt,
                            type: 'success',
                            buttons : {
                                confirm: {
                                    className : 'btn btn-success'
                                    //currLoc = $(location).attr('href');
                                }
                            }
                        });

                        window.location.href= $(location).attr('href');
                    },
                     error: function() {
                        alert('Error while request..');
                    }
                });

                
            } else {
                swal.close();
            }
        });
   // });
}
function assignRowValue(obj, formname, value) {
    var form = $('#' + formname);
    var row = $(obj).closest('.row');
    var fieldtext = row.find(obj).find("option:selected").html();
    row.find(value).val(fieldtext);

}